import type { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import Button from '@components/Button';
import Card from '@components/Card';
import Input from '@components/Input';
import type { RootTabParamList } from '@navigation/types';
import { colors, spacing, typography } from '@theme';

type HomeNavigationProp = BottomTabNavigationProp<RootTabParamList, 'Accueil'>;

export default function HomeScreen() {
  const navigation = useNavigation<HomeNavigationProp>();
  const [goal, setGoal] = useState('');

  const handleStart = () => {
    navigation.navigate('Pomodoro');
  };

  const handleLater = () => {
    Keyboard.dismiss();
    setGoal('');
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={styles.greeting}>Salut 👋</Text>
          <Text style={styles.subtitle}>Prêt à avancer aujourd'hui ?</Text>

          <Card style={styles.card}>
            <Text style={styles.cardTitle}>Bienvenue sur FocusAi-Student</Text>
            <Text style={styles.cardBody}>
              Fixe un objectif pour ta prochaine session, puis lance ton premier Pomodoro.
            </Text>

            <Input
              label="Objectif du jour"
              placeholder="Ex. Réviser 2h de maths"
              value={goal}
              onChangeText={setGoal}
              returnKeyType="done"
            />

            <View style={styles.actions}>
              <Button label="Commencer une session" onPress={handleStart} fullWidth />
              <Button label="Plus tard" onPress={handleLater} variant="ghost" fullWidth />
            </View>
          </Card>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  flex: {
    flex: 1,
  },
  content: {
    padding: spacing.lg,
  },
  greeting: {
    ...typography.h1,
    color: colors.textPrimary,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    marginBottom: spacing.xl,
  },
  card: {
    gap: spacing.sm,
  },
  cardTitle: {
    ...typography.h3,
    color: colors.textPrimary,
  },
  cardBody: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  actions: {
    gap: spacing.sm,
  },
});
