# screens/

Un fichier par écran, monté par le navigateur (React Navigation).

Un screen orchestre : il assemble des `components/`, lit l'état depuis `store/`,
déclenche des actions via `services/`. Il ne contient pas lui-même de logique
métier lourde ni de styles bas niveau réutilisables ailleurs.

**Présents depuis l'Étape 2**, montés par `navigation/RootNavigator.tsx` :
- `HomeScreen.tsx` — seul écran avec du vrai contenu pour l'instant (démontre Card/Input/Button ensemble + navigation vers l'onglet Pomodoro)
- `PomodoroScreen.tsx`, `CoachScreen.tsx`, `ProfileScreen.tsx` — placeholders au design cohérent, en attente de leur logique (Étapes 3, 5, 4/6)
