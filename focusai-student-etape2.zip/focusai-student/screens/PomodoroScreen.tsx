import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import Card from '@components/Card';
import { colors, spacing, typography } from '@theme';

export default function PomodoroScreen() {
  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <View style={styles.content}>
        <Card style={styles.card}>
          <View style={[styles.iconWrap, { backgroundColor: colors.primary }]}>
            <Ionicons name="timer-outline" size={28} color={colors.textOnPrimary} />
          </View>
          <Text style={styles.title}>Le minuteur arrive à l'Étape 3</Text>
          <Text style={styles.body}>
            Sessions Focus (25 min), pauses courtes et longues, suivi en arrière-plan : le
            moteur Pomodoro sera construit ici.
          </Text>
        </Card>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.background },
  content: { flex: 1, padding: spacing.lg, justifyContent: 'center' },
  card: { alignItems: 'center', padding: spacing.xl, gap: spacing.sm },
  iconWrap: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  title: { ...typography.h3, color: colors.textPrimary, textAlign: 'center' },
  body: { ...typography.body, color: colors.textSecondary, textAlign: 'center' },
});
