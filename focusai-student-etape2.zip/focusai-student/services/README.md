# services/

Logique métier et communication avec l'extérieur : appels à l'API Vercel,
authentification, moteur du timer Pomodoro, appels au Coach IA.

Un service est une fonction ou une classe **testable indépendamment de React** —
aucun hook, aucun JSX ici. Les screens et le store appellent les services ;
les services n'importent jamais de composants.

Prévu à partir de l'Étape 3 (moteur Pomodoro) puis Étape 4/5 (backend, Coach IA) :
`pomodoroEngine.ts`, `api.ts`, `authService.ts`, `coachService.ts`.
