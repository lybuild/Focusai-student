/**
 * Typographie — FocusAi-Student.
 *
 * Choix volontaire : la police système (San Francisco sur iOS, Roboto sur
 * Android) plutôt qu'une police custom chargée à froid. C'est littéralement
 * "le standard Apple/Google" demandé par la charte, ça évite le flash de
 * texte sans style au démarrage, et ça garde le bundle léger. La hiérarchie
 * vient du poids, de la taille et de l'espacement des lettres, pas de la
 * police elle-même — une police custom pourra être ajoutée plus tard (Étape 7)
 * sans que rien d'autre n'ait à changer.
 */
export const typography = {
  display: { fontSize: 56, fontWeight: '700', lineHeight: 60, letterSpacing: -1 },
  h1: { fontSize: 28, fontWeight: '700', lineHeight: 34, letterSpacing: -0.5 },
  h2: { fontSize: 22, fontWeight: '700', lineHeight: 28, letterSpacing: -0.25 },
  h3: { fontSize: 17, fontWeight: '600', lineHeight: 22 },
  body: { fontSize: 15, fontWeight: '400', lineHeight: 22 },
  bodyBold: { fontSize: 15, fontWeight: '600', lineHeight: 22 },
  caption: { fontSize: 13, fontWeight: '400', lineHeight: 18 },
  label: {
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 16,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
} as const;
