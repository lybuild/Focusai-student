/**
 * Palette de couleurs — FocusAi-Student.
 *
 * Les 4 couleurs de marque (primary, secondary, accent, background) sont
 * fixées par la charte du produit. Le reste (surfaces, textes, bordures,
 * feedback) est dérivé pour rester cohérent avec elles.
 */
export const colors = {
  // Marque
  primary: '#121826', // Deep Navy Blue — concentration, actions principales
  primaryMuted: '#2A3548', // navy éclairci, pour les états pressés/surfaces navy subtiles
  secondary: '#10B981', // Mint/Emerald — validation, succès
  secondaryMuted: '#D1FAE5', // fond mint très clair (badges, succès discrets)
  accent: '#8B5CF6', // Soft Purple — Coach IA
  accentMuted: '#EDE9FE', // fond violet très clair (bulles/éléments liés au Coach IA)

  // Sémantique
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444',
  dangerMuted: '#FEE2E2',

  // Surfaces
  background: '#F8FAFC', // Off-White/Light Gray — fond général
  surface: '#FFFFFF', // cartes, inputs, barres de nav
  border: '#E2E8F0',

  // Texte
  textPrimary: '#121826',
  textSecondary: '#64748B',
  textMuted: '#94A3B8',
  textOnPrimary: '#FFFFFF',
  textOnAccent: '#FFFFFF',
  textOnSecondary: '#FFFFFF',

  overlay: 'rgba(18, 24, 38, 0.5)', // fonds de modale/bottom-sheet (Étapes suivantes)
} as const;

export type ColorToken = keyof typeof colors;
