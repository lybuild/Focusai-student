/**
 * Espacements — grille de 4/8pt (standard Apple/Google), pour que tous les
 * écarts de l'app soient des multiples cohérents plutôt que des valeurs
 * choisies au pixel près à chaque écran.
 */
export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
  xxxl: 64,
} as const;

/** Rayons de bordure — angles généreux, cohérents avec un style épuré et doux. */
export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
} as const;
