/**
 * Ombres — utilise `boxShadow`, la propriété cross-platform introduite avec
 * la New Architecture (RN 0.76+, active par défaut ici). Un seul style pour
 * iOS et Android, plutôt que l'ancien duo "shadow-*" côté iOS + "elevation"
 * côté Android à dupliquer par plateforme.
 */
export const shadows = {
  sm: '0px 1px 3px rgba(18, 24, 38, 0.06)',
  md: '0px 4px 12px rgba(18, 24, 38, 0.08)',
  lg: '0px 8px 24px rgba(18, 24, 38, 0.12)',
} as const;
