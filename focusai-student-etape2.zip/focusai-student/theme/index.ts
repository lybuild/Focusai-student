export { colors } from './colors';
export type { ColorToken } from './colors';
export { typography } from './typography';
export { spacing, radius } from './spacing';
export { shadows } from './shadows';

import { colors } from './colors';
import { typography } from './typography';
import { spacing, radius } from './spacing';
import { shadows } from './shadows';

/** Objet unique regroupant tous les tokens, pour un accès rapide : theme.colors.primary */
export const theme = {
  colors,
  typography,
  spacing,
  radius,
  shadows,
} as const;
