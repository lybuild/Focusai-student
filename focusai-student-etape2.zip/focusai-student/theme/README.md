# theme/

Design tokens de l'application : couleurs, typographie, espacements, rayons,
ombres. Aucune donnée métier ici, uniquement des constantes visuelles.

- `colors.ts` — palette de marque + dérivés (surfaces, texte, feedback)
- `typography.ts` — échelle de tailles/poids (police système)
- `spacing.ts` — grille d'espacement + rayons de bordure
- `shadows.ts` — élévations (cross-platform via `boxShadow`)
- `index.ts` — exporte tout, individuellement ou regroupé dans `theme`

Règle : un composant ou un écran importe ses couleurs/tailles d'ici, jamais
de valeurs codées en dur (`'#121826'` ne doit apparaître nulle part ailleurs
dans le code).
