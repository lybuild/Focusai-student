# components/

Composants UI **réutilisables** et **génériques**, sans logique métier.

Un composant a sa place ici s'il est utilisé (ou destiné à l'être) dans plusieurs
écrans : boutons, cards, inputs, badges, indicateurs de progression, etc.

Règles :
- Un composant ne connaît jamais Zustand ni les services — il reçoit tout via `props`.
- Pas d'appel réseau, pas d'accès au store ici (→ `services/` et `store/`).
- Un composant = un fichier = un export par défaut.

**Présents depuis l'Étape 2**, tous construits sur les tokens de `@theme` —
aucune couleur ni taille codée en dur à l'intérieur :

- `Button.tsx` — 5 variantes (`primary`, `secondary`, `accent`, `ghost`, `danger`), états `loading`/`disabled`
- `Card.tsx` — conteneur de base, optionnellement cliquable (`onPress`)
- `Input.tsx` — champ de texte avec label, focus, message d'erreur
- `AnimatedPressable.tsx` — primitive interne (effet d'échelle au toucher), utilisée par Button et Card
