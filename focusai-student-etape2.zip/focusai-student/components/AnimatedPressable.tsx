import React from 'react';
import { Pressable, PressableProps, StyleProp, ViewStyle } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';

const AnimatedPressableBase = Animated.createAnimatedComponent(Pressable);

interface AnimatedPressableProps extends Omit<PressableProps, 'style' | 'children'> {
  /** Échelle atteinte pendant l'appui. 0.96 = discret, 0.9 = plus marqué. */
  scaleTo?: number;
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
}

/**
 * Pressable avec un léger effet d'échelle au toucher — la première brique
 * des "micro-animations fluides pour chaque action gratifiante" demandées
 * dans la charte. Utilisé par Button et par Card (quand elle est cliquable).
 */
export default function AnimatedPressable({
  scaleTo = 0.96,
  style,
  onPressIn,
  onPressOut,
  children,
  ...rest
}: AnimatedPressableProps) {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <AnimatedPressableBase
      style={[style, animatedStyle]}
      onPressIn={(event) => {
        scale.value = withTiming(scaleTo, { duration: 100 });
        onPressIn?.(event);
      }}
      onPressOut={(event) => {
        scale.value = withTiming(1, { duration: 150 });
        onPressOut?.(event);
      }}
      {...rest}
    >
      {children}
    </AnimatedPressableBase>
  );
}
