import React from 'react';
import { ActivityIndicator, StyleProp, StyleSheet, Text, ViewStyle } from 'react-native';

import { colors, radius, spacing, typography } from '@theme';

import AnimatedPressable from './AnimatedPressable';

export type ButtonVariant = 'primary' | 'secondary' | 'accent' | 'ghost' | 'danger';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: ButtonVariant;
  loading?: boolean;
  disabled?: boolean;
  fullWidth?: boolean;
  style?: StyleProp<ViewStyle>;
}

const VARIANT_STYLES: Record<
  ButtonVariant,
  { background: string; text: string; border?: string }
> = {
  primary: { background: colors.primary, text: colors.textOnPrimary },
  secondary: { background: colors.secondary, text: colors.textOnSecondary },
  accent: { background: colors.accent, text: colors.textOnAccent },
  danger: { background: colors.danger, text: colors.textOnPrimary },
  ghost: { background: 'transparent', text: colors.primary, border: colors.border },
};

/** Bouton de base de l'app. Toute action tapable dans l'UI passe par ce composant. */
export default function Button({
  label,
  onPress,
  variant = 'primary',
  loading = false,
  disabled = false,
  fullWidth = false,
  style,
}: ButtonProps) {
  const variantStyle = VARIANT_STYLES[variant];
  const isDisabled = disabled || loading;

  return (
    <AnimatedPressable
      onPress={onPress}
      disabled={isDisabled}
      accessibilityRole="button"
      accessibilityState={{ disabled: isDisabled, busy: loading }}
      style={[
        styles.base,
        {
          backgroundColor: variantStyle.background,
          borderColor: variantStyle.border ?? 'transparent',
          borderWidth: variantStyle.border ? 1 : 0,
          opacity: isDisabled ? 0.5 : 1,
          alignSelf: fullWidth ? 'stretch' : 'flex-start',
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={variantStyle.text} />
      ) : (
        <Text style={[styles.label, { color: variantStyle.text }]}>{label}</Text>
      )}
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  base: {
    paddingVertical: spacing.sm + 4,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
  },
  label: {
    ...typography.bodyBold,
  },
});
