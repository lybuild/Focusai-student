import React from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';

import { colors, radius, shadows, spacing } from '@theme';

import AnimatedPressable from './AnimatedPressable';

interface CardProps {
  children: React.ReactNode;
  onPress?: () => void;
  padded?: boolean;
  style?: StyleProp<ViewStyle>;
}

/** Conteneur de base : surface blanche sur fond off-white, ombre légère, coins arrondis. */
export default function Card({ children, onPress, padded = true, style }: CardProps) {
  const cardStyle = [styles.base, padded && styles.padded, style];

  if (!onPress) {
    return <View style={cardStyle}>{children}</View>;
  }

  return (
    <AnimatedPressable
      onPress={onPress}
      scaleTo={0.98}
      accessibilityRole="button"
      style={cardStyle}
    >
      {children}
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  base: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    boxShadow: shadows.sm,
  },
  padded: {
    padding: spacing.md,
  },
});
