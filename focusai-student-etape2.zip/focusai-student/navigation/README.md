# navigation/

Configuration de React Navigation : structure des routes, types, options des
écrans (icônes, couleurs de la tab bar). Pas de logique métier ici.

- `RootNavigator.tsx` — Bottom Tab Navigator (Accueil, Pomodoro, Coach IA, Profil)
- `types.ts` — `RootTabParamList`, pour une navigation typée de bout en bout

Si un onglet a besoin d'un flux à plusieurs écrans (ex. Pomodoro → détail
d'une session), on imbriquera un `Stack.Navigator` propre à cet onglet ici,
plutôt que d'alourdir le tab navigator racine.
