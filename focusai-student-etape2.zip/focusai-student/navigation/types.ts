/**
 * Routes de la navigation par onglets. `undefined` = aucun paramètre attendu.
 * Quand un écran aura besoin de paramètres (ex. ouvrir une session Pomodoro
 * précise depuis l'historique), on le déclarera ici pour garder toute la
 * navigation typée de bout en bout.
 */
export type RootTabParamList = {
  Accueil: undefined;
  Pomodoro: undefined;
  CoachIA: undefined;
  Profil: undefined;
};
