// Note : depuis le SDK Expo 52+, babel-preset-expo configure automatiquement
// le plugin Babel de Reanimated/Worklets dès que la librairie est installée.
// Ne PAS ajouter 'react-native-reanimated/plugin' ou 'react-native-worklets/plugin'
// manuellement ci-dessous : ça créerait un plugin en double et casserait les animations.
module.exports = function (api) {
  api.cache(true);

  return {
    presets: ['babel-preset-expo'],
    plugins: [
      [
        'module-resolver',
        {
          root: ['./'],
          alias: {
            '@components': './components',
            '@screens': './screens',
            '@services': './services',
            '@store': './store',
            '@utils': './utils',
            '@assets': './assets',
            '@theme': './theme',
            '@navigation': './navigation',
          },
          extensions: ['.ios.ts', '.android.ts', '.ts', '.ios.tsx', '.android.tsx', '.tsx', '.jsx', '.js', '.json'],
        },
      ],
    ],
  };
};
