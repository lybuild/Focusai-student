# utils/

Fonctions pures, sans état et sans dépendance à React ou React Native :
formatage de durées, calculs de dates, helpers de validation, constantes
partagées non liées au design (celles-ci vivront dans le thème à l'Étape 2).

Une fonction ici doit pouvoir être testée avec un simple `input → output`,
sans mock ni provider.
