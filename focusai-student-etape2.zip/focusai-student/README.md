# FocusAi-Student

**Maîtrise ton temps, libère ton potentiel.**

Timer Pomodoro + Deep Focus + Coach IA pour étudiants, avec gamification
(streaks, XP, statistiques). Application mobile construite avec Expo /
React Native.

---

## Statut du projet

- [x] Étape 1 — Initialisation & Architecture
- [x] **Étape 2 — Design System & Navigation** ← tu es ici
- [ ] Étape 3 — Moteur Pomodoro & Focus (offline first)
- [ ] Étape 4 — Backend Vercel & base de données
- [ ] Étape 5 — Coach IA étudiant
- [ ] Étape 6 — Rétention & gamification
- [ ] Étape 7 — Polissage, animations & déploiement

## Stack technique

| Domaine | Choix | Pourquoi |
|---|---|---|
| Framework mobile | **Expo (React Native) + TypeScript** | itération rapide, test en direct sur ton téléphone Android via Expo Go (aucun Android Studio requis pour développer), animations fluides via Reanimated. Reste cross-platform si iOS devient pertinent plus tard. |
| Navigation | **React Navigation** (`bottom-tabs` + `native-stack`) | standard de facto en RN, gère nativement le Bottom Tab Navigator prévu à l'Étape 2 |
| Gestion d'état | **Zustand** | API minimale, aucun boilerplate de reducers/actions, très bonnes perfs, scale bien à mesure que l'app grossit (un store par domaine, voir `store/README.md`) |
| Animations | **Reanimated 4** + **react-native-worklets** + **Lottie** | animations 60fps sur le thread UI (streaks animés, transitions, micro-interactions) |
| Fondations gestes | **react-native-gesture-handler**, **react-native-screens**, **react-native-safe-area-context** | dépendances natives requises par React Navigation et par les futurs gestes (swipe, drag) |

**Versions installées** (voir `package.json` pour la liste exacte) : Expo SDK 57,
React Native 0.86, React 19.2, TypeScript 6.0.

## Démarrage

Prérequis : Node.js 20+ installé sur l'ordinateur qui fera tourner le serveur
de développement (le test lui-même se fait ensuite sur ton téléphone).

```bash
npm install
npm run start
```

Le terminal affiche un QR code. Scanne-le avec l'app **Expo Go** (Android/iOS)
installée sur ton téléphone — l'app se charge en direct, sans build ni APK,
avec rechargement à chaud à chaque modification du code.

Autres commandes utiles :

```bash
npm run android    # ouvre directement sur un émulateur/téléphone Android connecté
npm run web        # lance une preview dans le navigateur
npm run typecheck  # vérifie l'ensemble du projet avec TypeScript, sans rien compiler
```

## Architecture des dossiers

```
focusai-student/
├── App.tsx                # point d'entrée : providers globaux + navigation, rien d'autre
├── theme/                  # design tokens : couleurs, typo, espacements, ombres
├── navigation/             # Bottom Tab Navigator + types de routes
├── components/             # composants UI réutilisables (Button, Card, Input, ...)
├── screens/                # un fichier = un écran, monté par le navigateur
├── services/               # logique métier + appels réseau (API, auth, moteur Pomodoro, IA)
├── store/                  # état global (Zustand), un store par domaine
├── utils/                  # fonctions pures, sans dépendance à React
├── assets/                 # icônes, splash screen, futures animations Lottie
├── babel.config.js         # preset Expo + alias de chemins
└── tsconfig.json            # config TypeScript stricte + mêmes alias côté typage
```

`theme/` et `navigation/` ne faisaient pas partie de la liste de dossiers de
l'Étape 1 — ajoutés à l'Étape 2 une fois que leur contenu (tokens, routes)
existait réellement, plutôt que de les faire vivre ailleurs par défaut.
Chaque dossier a son propre `README.md` qui précise ce qui a sa place dedans.

### Alias de chemins

Plutôt que des imports relatifs fragiles (`../../../components/Button`), chaque
dossier racine a son alias, actif à la fois côté TypeScript et côté bundler :

```ts
import Button from '@components/Button';
import { colors, spacing } from '@theme';
import type { RootTabParamList } from '@navigation/types';
```

## Design System

| Rôle | Couleur | Usage |
|---|---|---|
| `colors.primary` | `#121826` Navy | actions principales, texte, tab active par défaut |
| `colors.secondary` | `#10B981` Mint | succès, validation, onglet Profil/Stats |
| `colors.accent` | `#8B5CF6` Violet | tout ce qui touche au Coach IA |
| `colors.background` / `colors.surface` | `#F8FAFC` / `#FFFFFF` | fond de page / cartes |

Typographie : police système (pas de police custom chargée), hiérarchie par
poids/taille (`typography.display` → `typography.caption`). Espacements sur
grille 4/8pt (`spacing.xs` → `spacing.xxxl`). Détails dans `theme/README.md`.

**Composants disponibles** : `Button` (5 variantes), `Card` (optionnellement
cliquable), `Input` (label + erreur) — tous animés au toucher via Reanimated.
Utilisés ensemble sur l'écran Accueil, à regarder en premier après un
`npm run start`.

## Notes techniques (pour la suite du projet)

- **Reanimated / Worklets** : ne jamais ajouter `react-native-reanimated/plugin`
  ou `react-native-worklets/plugin` à la main dans `babel.config.js`. Depuis le
  SDK Expo 52+, `babel-preset-expo` l'injecte automatiquement dès que la
  librairie est installée — l'ajouter en double casse les animations en
  silence (l'app tourne, mais les animations ne se déclenchent plus).
- **`GestureHandlerRootView`** et **`SafeAreaProvider`** sont déjà posés dans
  `App.tsx` : ce sont des fondations qui doivent englober toute l'app, donc
  autant les poser dès l'Étape 1 plutôt que de tout réenvelopper plus tard.
- **`@expo/vector-icons`** n'est plus fourni automatiquement avec le SDK 57
  (il l'était sur d'anciens SDK) — il est maintenant en dépendance explicite
  dans `package.json`, sinon `import { Ionicons } from '@expo/vector-icons'`
  échoue au runtime.
- **Ombres** : `theme/shadows.ts` utilise `boxShadow` (string cross-platform,
  disponible nativement depuis RN 0.76+ / New Architecture) plutôt que l'ancien
  duo `shadowColor/shadowOpacity/...` (iOS) + `elevation` (Android) à gérer
  séparément par plateforme.
- **⚠️ À surveiller pour l'Étape 7 (perf)** : `@expo/vector-icons` embarque
  par défaut les fichiers de *toutes* les familles d'icônes (Ionicons,
  FontAwesome6, MaterialCommunityIcons...) même si seule `Ionicons` est
  utilisée ici — plusieurs Mo d'assets inutiles dans le bundle final. Se
  limiter à la police `Ionicons.ttf` seule fera partie du nettoyage de
  performance prévu à l'Étape 7.
- Le bundle a été vérifié de bout en bout (`expo export --platform android`,
  1360 modules) : navigation, thème, composants, écrans, Reanimated,
  Worklets, Lottie, Zustand, icônes et alias de chemins fonctionnent tous
  ensemble sans conflit.

## Prochaine étape

Tape **SUITE** pour lancer l'Étape 3 : moteur Pomodoro (Focus 25 min / pause
courte / pause longue), minuteur fiable en arrière-plan, interface circulaire
animée.
