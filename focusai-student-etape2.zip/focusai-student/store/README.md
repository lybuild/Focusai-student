# store/

État global de l'application, géré avec **Zustand**.

Un store par domaine métier plutôt qu'un store monolithique unique — plus simple
à faire évoluer et à tester à mesure que l'app grossit :
`useSessionStore`, `useUserStore`, `useGamificationStore`.

Le store lit/écrit via `services/` (jamais d'appel réseau direct dans un store)
et expose des hooks consommés par les `screens/`.

Le premier store (session Pomodoro) arrive à l'Étape 3.
